"""OpenRouter LLM adapter implementing LLMInterface."""

import asyncio
import json
import time
from collections.abc import AsyncIterator

import httpx

from app.core.config import settings
from app.core.logging import logger
from app.providers.llm.interface import LLMInterface
from app.providers.types import LLMMessage, LLMResponse, StreamChunk, ToolSchema

_OPENROUTER_CHAT_URL = "https://openrouter.ai/api/v1/chat/completions"

# Bounded deadline for draining the SSE tail after an early consumer stop.
_SSE_DRAIN_TIMEOUT_S = 1.0


class OpenRouterAdapter(LLMInterface):
    """OpenRouter adapter for LLM chat completions.

    Uses the OpenAI-compatible OpenRouter REST API.
    Requires OPENROUTER_API_KEY in environment configuration.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        default_model: str | None = None,
        timeout: float | None = None,
    ) -> None:
        resolved_key = api_key or settings.openrouter_api_key
        if not resolved_key:
            raise ValueError("OpenRouter API key not configured. Set OPENROUTER_API_KEY.")

        self._api_key = resolved_key
        self._default_model = default_model or settings.default_llm_model or ""
        self._timeout = timeout or settings.llm_timeout
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(self._timeout),
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
        )
        logger.debug(
            "OpenRouter adapter initialized model=%s",
            self._default_model or "default",
        )

    @property
    def provider_name(self) -> str:
        return "openrouter"

    async def chat(
        self,
        messages: list[LLMMessage],
        *,
        model: str | None = None,
        tools: list[ToolSchema] | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> LLMResponse:
        """Send a chat completion request to OpenRouter."""
        resolved_model = model or self._default_model
        payload = self._build_payload(
            messages,
            resolved_model,
            tools,
            temperature,
            max_tokens,
        )

        request_start = time.monotonic()
        try:
            response = await self._client.post(_OPENROUTER_CHAT_URL, json=payload)
            duration_ms = (time.monotonic() - request_start) * 1000
            response.raise_for_status()

        except httpx.HTTPStatusError as e:
            status = e.response.status_code
            duration_ms = (time.monotonic() - request_start) * 1000
            try:
                error_body = e.response.json()
                detail = error_body.get("error", {}).get("message", "")
            except Exception:
                detail = e.response.text[:200]
            if status == 401:
                logger.error(
                    "[LLM] provider=openrouter model=%s status=error "
                    "duration_ms=%.0f error=auth_failed",
                    resolved_model,
                    duration_ms,
                )
                raise RuntimeError("OpenRouter authentication failed") from e
            logger.error(
                "[LLM] provider=openrouter model=%s status=error "
                "duration_ms=%.0f error=%s",
                resolved_model,
                duration_ms,
                detail[:200],
            )
            raise RuntimeError(f"OpenRouter API error: HTTP {status} — {detail}") from e

        except httpx.TimeoutException:
            duration_ms = (time.monotonic() - request_start) * 1000
            logger.error(
                "[LLM] provider=openrouter model=%s status=error "
                "duration_ms=%.0f error=timeout",
                resolved_model,
                duration_ms,
            )
            raise RuntimeError("OpenRouter request timed out")

        except httpx.HTTPError as e:
            logger.error("[LLM] provider=openrouter model=%s error_type=%s",
                         resolved_model, type(e).__name__)
            raise RuntimeError(f"OpenRouter HTTP error: {e}") from e

        data = response.json()
        result = self._parse_response(data)
        logger.info(
            "[LLM] provider=openrouter model=%s duration_ms=%.0f "
            "tokens_in=%s tokens_out=%s",
            resolved_model,
            duration_ms,
            result.usage.get("prompt_tokens", "n/a"),
            result.usage.get("completion_tokens", "n/a"),
        )
        return result

    async def stream_chat(
        self,
        messages: list[LLMMessage],
        *,
        model: str | None = None,
        tools: list[ToolSchema] | None = None,
        temperature: float = 0.7,
        max_tokens: int | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Stream chat completion chunks from OpenRouter.

        Yields StreamChunk objects with either text content or tool call
        deltas, matching the OpenAI-compatible SSE streaming protocol.
        """
        resolved_model = model or self._default_model
        payload = self._build_payload(
            messages,
            resolved_model,
            tools,
            temperature,
            max_tokens,
        )
        payload["stream"] = True

        try:
            async with self._client.stream(
                "POST",
                _OPENROUTER_CHAT_URL,
                json=payload,
            ) as response:
                response.raise_for_status()
                lines = response.aiter_lines()
                finish_seen = False
                try:
                    async for line in lines:
                        if not line.startswith("data: "):
                            continue
                        data_str = line[6:]
                        if data_str.strip() == "[DONE]":
                            break

                        chunk = json.loads(data_str)
                        choices = chunk.get("choices", [])
                        if not choices:
                            continue

                        delta = choices[0].get("delta", {})
                        finish = choices[0].get("finish_reason")
                        content = delta.get("content")
                        tool_calls = delta.get("tool_calls")

                        if content or tool_calls or finish:
                            if finish:
                                finish_seen = True
                            yield StreamChunk(
                                content=content,
                                tool_calls=tool_calls,
                                finish_reason=finish,
                            )
                except GeneratorExit:
                    # The consumer stopped right after the final finish_reason
                    # chunk: read the remaining SSE tail (data: [DONE] + HTTP
                    # body terminator) so httpcore can pool the connection
                    # instead of closing it. Generator close runs in the
                    # event loop's finalizer task, so the caller is never
                    # delayed. Bounded to 1s; cancellation is never
                    # suppressed, and interrupted streams are not drained.
                    if finish_seen:
                        try:
                            async with asyncio.timeout(_SSE_DRAIN_TIMEOUT_S):
                                async for _ in lines:
                                    pass
                        except Exception:
                            pass
                    raise

        except httpx.HTTPStatusError as e:
            logger.error("OpenRouter stream error: HTTP %d", e.response.status_code)
            raise RuntimeError(f"OpenRouter stream error: HTTP {e.response.status_code}") from e

        except httpx.HTTPError as e:
            logger.error("OpenRouter stream HTTP error: %s", e)
            raise RuntimeError(f"OpenRouter stream error: {e}") from e

    async def close(self) -> None:
        await self._client.aclose()

    def _build_payload(
        self,
        messages: list[LLMMessage],
        model: str,
        tools: list[ToolSchema] | None,
        temperature: float,
        max_tokens: int | None,
    ) -> dict:
        """Build the OpenAI-compatible request payload."""
        payload: dict = {
            "model": model,
            "messages": [self._serialize_message(m) for m in messages],
            "temperature": temperature,
        }

        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        if tools:
            payload["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t.name,
                        "description": t.description,
                        "parameters": t.parameters,
                    },
                }
                for t in tools
            ]

        return payload

    @staticmethod
    def _serialize_message(msg: LLMMessage) -> dict:
        """Convert a generic LLMMessage to OpenAI-compatible dict."""
        result: dict = {"role": msg.role}

        if msg.content is not None:
            result["content"] = msg.content

        if msg.tool_calls is not None:
            result["tool_calls"] = msg.tool_calls

        if msg.tool_call_id is not None:
            result["tool_call_id"] = msg.tool_call_id

        if msg.name is not None:
            result["name"] = msg.name

        return result

    @staticmethod
    def _parse_response(data: dict) -> LLMResponse:
        """Parse OpenRouter/OpenAI-compatible response into LLMResponse."""
        choices = data.get("choices", [])

        if not choices:
            return LLMResponse(
                content=None,
                finish_reason="empty",
                metadata={"raw": data},
            )

        choice = choices[0]
        message = choice.get("message", {})
        content = message.get("content")
        tool_calls = message.get("tool_calls")
        finish_reason = choice.get("finish_reason", "stop")

        usage_data = data.get("usage", {})
        usage = {
            "prompt_tokens": usage_data.get("prompt_tokens", 0),
            "completion_tokens": usage_data.get("completion_tokens", 0),
            "total_tokens": usage_data.get("total_tokens", 0),
        }

        logger.debug(
            "OpenRouter response tokens=%s finish=%s",
            usage.get("total_tokens"),
            finish_reason,
        )

        return LLMResponse(
            content=content,
            tool_calls=tool_calls,
            finish_reason=finish_reason,
            usage=usage,
            metadata={"provider": "openrouter", "model": data.get("model", "")},
        )
